import React from 'react';
import ReactDOM from 'react-dom/client';
import GolfScorecardApp from './GolfScorecardApp';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <GolfScorecardApp />
  </React.StrictMode>
);
